import numpy as np
import pandas as pd
from joblib import load

# Preprocessing Libraries
from sklearn.preprocessing import OneHotEncoder, StandardScaler


dates = ['creation_date', 'invoice_date']  # features to be changed to datetime
objs = ['disrict', 'region']  # features to be changed to categorical
integer = ['counter_statue', 'target']


def transform(df):
    """This function takes in a dataframe transforms the data type of columns in
    the objs and dates list, and also creates new columns of day, month & year from the dates columns"""

    # features to be changed to datetime
    dates = ['creation_date', 'invoice_date']
    objs = ['disrict', 'region','counter_type','client_id']  # features to be changed to categorical
    #integer = ['counter_statue', 'target']

    for col in df:
        if col in objs:
            df[col] = df[col].astype(str)
        elif col in dates:
            df[col] = pd.to_datetime(df[col])
            df[col+"_"+"year"] = pd.DatetimeIndex(df[col]).year
            df[col+"_"+"month"] = pd.DatetimeIndex(df[col]).month
            df[col+"_"+"day"] = pd.DatetimeIndex(df[col]).day
        elif col not in objs and col not in dates:
            df[col] = df[col].astype(int)
    return df


def encoder(df):
    """This function takes in a dataframe, encodes the categorical columns 
and returns an encoded dataframe"""
    df = transform(df)
    categorical_cols = ['disrict', 'region','counter_type']
    #for col in df.columns:
        #if df[col].dtype == 'object' and col != 'client_id':
            #categorical_cols.append(col)

    ohe = load('../Resources/encoder.joblib')

    # One-hot-encode the categorical columns.
    # Unfortunately outputs an array instead of dataframe.
    array_hot_encoded = ohe.transform(df[categorical_cols]).toarray()

    # extracting the featurelabels after encoding . To be used in building the final train dataframe
    feature_labels = ohe.get_feature_names()
    # using ravel to get a flattened 1D array of the feature labels
    feature_labels = np.array(feature_labels).ravel()

    # Convert it to df
    data_hot_encoded = pd.DataFrame(
        array_hot_encoded, columns=feature_labels, index=df.index)

    # Extract only the columns that didnt need to be encoded
    data_other_cols = df.drop(columns=categorical_cols)

    # Concatenate the two dataframes :
    data_out = pd.concat([data_other_cols, data_hot_encoded], axis=1)

    return data_out


def scaling(df):
    """This function takes in a dataframe and scales the numerical columns,
    and drops the unnecessary columns not needed for the model to predict"""
    df = encoder(df)
    numericals = []
    not_include = ['target']
    datatypes = ['datetime64[ns]', 'object']
    for col in df:
        if col not in not_include and df[col].dtype not in datatypes:
            numericals.append(col)
    scaler = load('../Resources/std_scaler.joblib')

    df[numericals] = scaler.fit_transform(df[numericals])
    final_df = df.drop(['client_id', 'invoice_date', 'creation_date'], axis=1)
    return final_df
