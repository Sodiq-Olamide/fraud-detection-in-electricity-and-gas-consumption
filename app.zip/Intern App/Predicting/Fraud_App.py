
# Streamlit dependencies
import os
import joblib
from data_prep import scaling
import pandas as pd
import pandas_profiling
from PIL import Image
import seaborn as sns
import matplotlib.pyplot as plt
import streamlit as st
import pickle
st.set_option('deprecation.showPyplotGlobalUse', False)
#import st_aggrid
from st_aggrid import AgGrid
from st_aggrid import GridOptionsBuilder, AgGrid, GridUpdateMode, DataReturnMode
from pandas_profiling import ProfileReport
from streamlit_pandas_profiling import st_profile_report
# Data dependencies

# Custom Libraries
#one has to pip install streamlit-aggrid
# Load your raw data
#raw = pd.read_csv("../Resources/merged_test.csv")


# The main function where we will build the actual app
def main():
    """Fraud Classifier App with Streamlit """

    # Creates a main title and subheader on your page -
    # these are static across all pages
    image = Image.open("../Resources/Images/logo 5.jpg")
    image = image.resize((500,150))
    st.image(image,use_column_width=True)
    st.title("Fraud Classifier")
    st.subheader(
        "_Fraud Detection in Electricity and Gas Consumption For STEG, Tunisia_")

    # Creating sidebar with selection box -
    # you can create multiple pages this way
    options = ["Home", "Data Overview", "Solution Overview","Prediction"] #"Select Data","Enter Data"]
    
    selection = st.sidebar.selectbox("Navigation", options)
    st.sidebar.image("../Resources/Images/logo 2.JPG ",use_column_width=True)
    # Load your raw data
    data = pd.read_csv("../Resources/Data/merged_test.csv")

    if selection == "Prediction":
        methods=["Select Data", "Enter Data"]
        input_choice = st.sidebar.selectbox("Choose Your Input Method", methods)
        if input_choice == "Select Data":
            models = ["Decision Tree", "Logistic Regression",
                "Multinomial Naive Bayes", "Bagging Model"]
            model_choice = st.sidebar.selectbox("Choose Your Model", models)
            st.info("Make a classification using our {} model".format(model_choice))
            gb = GridOptionsBuilder.from_dataframe(data)
            gb = GridOptionsBuilder.from_dataframe(data)
            gb.configure_pagination(paginationAutoPageSize=True) #Add pagination
            gb.configure_side_bar() #Add a sidebar
            gb.configure_selection('multiple', use_checkbox=True, groupSelectsChildren="Group checkbox select children") #Enable multi-row selection
            gridOptions = gb.build()

            grid_response = AgGrid(
                data,
                gridOptions=gridOptions,
                data_return_mode='AS_INPUT', 
                update_mode='MODEL_CHANGED', 
                fit_columns_on_grid_load=False,
                theme='blue', #Add theme color to the table
                enable_enterprise_modules=True,
                height=350, 
                width='100%',
                reload_data=True
            )

            data = grid_response['data']
            selected = grid_response['selected_rows'] 
            df = pd.DataFrame(selected) #Pass the selected rows to a new dataframe df
            user_input = df




        # Building out the prediction page
        if input_choice == "Enter Data":

            # Creating a dictionary to store  user input
            dict = {}
            models = ["Decision Tree", "Logistic Regression",
                "Multinomial Naive Bayes", "Support Vector Machine"]
            model_choice = st.sidebar.selectbox("Choose Your Model", models)
            st.info("Make a classification using our {} model".format(model_choice))

            # adding user input to dictionary
            dict["client_id"] = [st.text_input("Enter client ID")]
            dict["invoice_date"] = [st.date_input("Enter date of invoice in the format dd/mm/yyyy")]
            dict["tarif_type"] = [st.number_input("Enter tarif type")]
            dict["counter_number"] = [st.number_input("Enter counter number")]
            dict["counter_statue"] = [st.selectbox("Select counter statue",(0,1,3,4,5))]
            dict["counter_code"] = [st.number_input("Enter counter code")]
            dict["reading_remarque"] = [st.number_input(
                "Enter reading remarque")]
            dict["counter_coefficient"] = [st.number_input(
                "Enter counter coefficient")]
            dict["consommation_level_1"] = [st.number_input(
                "Enter level 1's energy consumation")]
            dict["consommation_level_2"] = [st.number_input(
                "Enter level 2's energy consumation")]
            dict["consommation_level_3"] = [st.number_input(
                "Enter level 3's energy consumation")]
            dict["consommation_level_4"] = [st.number_input(
                "Enter level 4's energy consumation")]
            dict["old_index"] = [st.number_input("Enter client's old index")]
            dict["new_index"] = [st.number_input("Enter client's new index")]
            dict["months_number"] = [st.number_input(
                "Enter approximate total months of active energy consumption")]
            dict["counter_type"] = [st.selectbox("Select counter type",('GAZ', 'ELEC'))]
            dict["disrict"] = [st.selectbox("Select clients district",(60, 62, 63, 69))]
            dict["client_catg"] = [st.number_input("Enter client's category")]
            dict["region"] = [st.number_input("Enter client's region")]
            dict["creation_date"] = [st.date_input(
                "Enter date client joined the company in the format dd/mm/yyyy")]
            user_input = pd.DataFrame.from_dict(dict)

        if st.button("Classify"):
            try:
                        # Transforming user input with vectorizer
                #user_input = pd.DataFrame.from_dict(dict)
                user_input = scaling(user_input)
                        # Load your .pkl file with the model of your choice + make predictions
                        # Try loading in multiple models to give the user a choice
                if model_choice == 'Decision Tree':
                    #st.subheader("Classify with: {}".format(model_choice))
                    predictor =pickle.load(open('../Resources/DTree_model.pkl', 'rb'))  
                    prediction = predictor.predict(user_input)
                # st.write(prediction)
                    # elif model_choice == 'Random Forest':
                        #predictor = joblib.load(open(os.path.join("resources/RFC.pkl"),"rb"))
                        #prediction = predictor.predict(vect_text)
                # st.write(prediction)
                elif model_choice == 'Logistic Regression':
                    predictor = joblib.load(open(os.path.join("../Resources/lr_model.pkl"), "rb"))
                    prediction = predictor.predict(user_input)
                # st.write(prediction)
                elif model_choice == 'Multinomial Naive Bayes':
                    predictor = joblib.load(open(os.path.join("../Resources/MNB_model.pkl"), "rb"))
                    prediction = predictor.predict(user_input)

                elif model_choice == 'Bagging Model':
                    predictor = joblib.load(open(os.path.join("../Resources/bagging_model.pkl"), "rb"))
                    prediction = predictor.predict(user_input)

                    # When model has successfully run, will print prediction
                    # You can use a dictionary or similar structure to make this output
                    # more human interpretable.
                
                
                if len(prediction) == 1:
                    if prediction == 1:
                        st.success(f"Client Categorized as: {prediction}, a fraud")
                    else:
                        st.success(f"Client Categorized as: {prediction}, a non-fraud")
                else:
                    for i in range(len(prediction)):
                        if prediction[i] == 1:
                            st.success(f"Client {i} Categorized as: {prediction[i]}, a fraud")
                        elif prediction[i] == 0:
                            st.success(f"Client {i} Categorized as: {prediction[i]}, a non-fraud")
            except ValueError:
                st.error("Please check to ensure all input values are provided. Ensure inputs for both Invoice and Creation dates are provided in the correct format")
            except KeyError:
                st.error("You have not made a selection to classify. Please try again. If you can't find the client, you can try enter their data in the Enter Data option.")
                #st.success("Client Categorized as: {}".format(prediction))


    #building the home page
    if selection == "Home":
        st.image("../Resources/Images/logo 1.png",use_column_width=True)
        st.markdown("**The Tunisian Company of Electricity and Gas (STEG)** is a public and a non-administrative company, which is responsible for delivering electricity and gas across Tunisia.") 
        st.markdown("In the recent past, the company suffered tremendous losses in the order of 200 million Tunisian Dinars due to fraudulent manipulations of meters by consumers. ")
        st.markdown("Using the client’s billing history, a challenge was presented to detect and recognize clients involved in fraudulent activities.")
        st.markdown("Using Machine learning technology we were able to build a model solution which will enhance the company’s revenues and reduce the losses caused by such fraudulent activities.")

    if selection == "Data Overview":
        client = pd.read_csv("../Resources/Data/client_train.csv")
        invoice = pd.read_csv("../Resources/Data/invoice_train.csv")
        st.markdown("## Data Overview")
        
        st.markdown("let's take a look at the data in two steps, one being the composition and two, the key insights we were able to draw from the data that came in handy during modelling.")
        
        st.markdown("### 1. Data Composition")
        
        st.markdown("The data provided by STEG was composed of two files. The first one is comprised of client data and the second one contains billing history since 2005.")
        st.markdown("The two sets of data, client data and invoice data, were provided for both the training and test data")
        st.markdown("The Client train data comprised of 135,493 samples and 6 features while the Invoice Train data comprised of 4,476,749 samples and 16 features.")
        st.markdown("The target feature, was made available in the client data and comprised of two classes; 0 - No Fraud, 1 - Fraud.")
        st.markdown("You can view the top ten samples from the two data sets by clicking view below")
        if st.button('View Client Data'):
            AgGrid(client.head(10))
        if st.button("View Invoice Data"):
            AgGrid(invoice.head(10))
        
        st.markdown("### 2. EDA Key Insights")

        st.markdown("Further exploration of the data led us to discovering deeper insights of the data some of which were employed in the feature engineering stage during Model building.")
        st.markdown("Below we take a quick look into some of the discoveries.")

        st.markdown("#### a) Target Class Distribution")
        st.markdown("The target class comprised of two classes, fraud and non-fraud with the non-fraud group being the majority as seen in the below graph visualization.")
        st.image("../Resources/Images/Target Class.png",use_column_width=True)

        st.markdown("### b) Fraud Cases per District")
        st.markdown("From the below graph visualization, we are able to see that the district labelled 69 recorded the highest cases of fraud while the district labelled as 60, recorded the lowest cases of fraud in gas & electricity.")
        st.image("../Resources/Images/District Frauds.png")#,use_column_width=True)

        st.markdown("### c) Fraud Cases per Region")
        st.markdown("From the below graph visualization, we can see that some regions had extremely high number of fraud cases, of above 50,000 like region 311 & 101, while some regions like 206 & 399 had zero cases of fraud. ")
        st.image("../Resources/Images/Region Frauds.png")#,use_column_width=True)

        st.markdown("### d) Fraud Cases per Counter Type")
        st.markdown("There are two counter types, gas and electricity, labelled as GAZ and ELEC respectively. From the below graph we can see that more fraud cases were recorded for Electricity counter type than the Gas counter")
        st.image("../Resources/Images/Counter Frauds.png")#,use_column_width=True)

        st.markdown("### e) Fraud Cases per Invoice Year")
        st.markdown("Depending on the year the fraud cases were recorded, more fraud cases were recorded in the most recent years like 2017 & 2016 while the least fraud cases were recorded as far as the year 2005.")
        st.image("../Resources/Images/Year Frauds.png")#,use_column_width=True)

        st.markdown("### f) Fraud Cases per Invoice Month")
        st.markdown("With regards to the Invoice dates when the fraud cases were recorded, we can see in the below graph, that the highest number of fraud cases were recorded in the first 5 months of the year with the least record being made in the last month of the year.")
        st.image("../Resources/Images/Month Frauds.png")#,use_column_width=True)

        st.markdown("### g) Fraud Cases per Invoice Day")
        st.markdown("With regards to the Invoice dates when the fraud cases were recorded, we can see in the below graph, that the highest number of fraud cases were recorded in the first days of the month, particularly day 5, 9 and 1 while the least number of cases were recorded in the last days of the month, specifically day 31, 30 and 29.")
        st.image("../Resources/Images/Day Frauds.png")#,use_column_width=True)

    if selection == "Solution Overview":
        st.markdown("## Solution Overview")
        st.markdown("Here we'll talk about the steps taken in preparing the data for modelling and also the modelling phase.")
        st.markdown("We'll do this in two steps, the feature engineering and the modelling phase")

        st.markdown("### 1. Feature Engineering")

        st.markdown("In this stage, we first merged the client data and the invoice data on the Client ID, which then led to us having 4,476,749 samples and 21 features inclusive of the target feature. You can click view below to have a glimpse of the data without the target feature.")
        if st.button('View Merged Data'):
            AgGrid(data.head(10))


        st.markdown("The other transformations done on the data include changing the data types of the categorical features to object to enable encoding and also scaling the numerical features. For the encoding we used SKlearn's OneHotEncoder and for the scaling we used SKlearn's StandardScaler.")
        st.markdown("After perfoming those data transformations we split the training data into 80% training set and 20% validation set, a necessary step to enable us track the perfomance of our models. Given our data was imbalanced, we finally sampled the split data set in two ways, upsampling and downsampling where both sampled sets and the unsampled set were used in modelling separately. This was made possible using both of Imblearn's RandomOverSampler and RandomUnderSampler.")
        st.markdown("Below is an illustration of the concept of sampling for better understanding.")
        st.image("../Resources/Images/Sampling.png",use_column_width=True) 

        st.markdown("### 1. Modelling")
        st.markdown("Here, six models were built, namely; **Bagged Model Classifier, Decision Tree Classifier, Random Forest Classifier, Logistic Regression Classifier, Multinomial Naive Bayes and Support Vector Machine Classifier.**")   
        st.markdown("These models were trained on both the sampled datasets and also the unsampled data set, with the perfomance of each model being measured by F1 score and the training time")

        st.markdown("#### Model perfomance on the Not Sampled data set")
        st.markdown("In the below graph, we can see for the data set without any sampling done, Decision Tree model perfomed in terms of the F1 score and fairly well in the training time, while the support vector machine model perfomed the poorest in terms of F1 score even though it had the lowest training time.")
        st.image("../Resources/Images/No Sampling.png",use_column_width=True)

        st.markdown("#### Model perfomance on the Over Sampled data set")
        st.markdown("In the below graph, we can see that for this over sampled data set, the bagged model perfomed the best in terms of the F1 score and fairly well on the training time while the Support Vector Machine perfomed the poorest in terms of the F1 score even though it had the lowest training time.")
        st.image("../Resources/Images/Over Sampled.png",use_column_width=True)

        st.markdown("### Model Perfomance on the Under Sampled data set")
        st.markdown("In the below graph, we can see that once again the bagged model perfoms the best in terms of the F1 score with a fairly good training time while the support vector machine perfomed the poorest in terms of the F1 score even though, even here, it had the lowest training time.")
        st.image("../Resources/Images/Under Sampled.png",use_column_width=True)


        st.markdown("**In conclusion,** the Bagged model perfomed very well across all the data sets, with the Random Forest classifier perfoming very well too in terms of the F1 score on the sampled data sets but having a the highest training time across all the data sets. This is not good in a production environment where output is needed under minimal time.")
        st.markdown(" Given the F1 score is a robust measure when dealing with imbalanced data sets as it captures both the precision and recall scores in its calculations, we can confidently say that the bagged model and the decision tree classifier, were our best perfoming models across the different data sets.")


# Required to let Streamlit instantiate our web app.
if __name__ == '__main__':
    main()
